import Link from "next/link";
import { localePath, type Locale } from "@/lib/i18n";
import type { Dict } from "@/lib/dictionaries";

export default function Footer({ locale, t }: { locale: Locale; t: Dict }) {
  const p = (path: string) => localePath(locale, path);
  return (
    <footer className="mt-16 border-t border-brand-line bg-brand-soft">
      <div className="mx-auto max-w-5xl px-4 py-8 text-sm text-muted">
        <div className="mb-3 flex flex-wrap gap-x-5 gap-y-1">
          <Link href={p("/is-elanlari/baki/satis-marketinq")}>{t.footer.sales}</Link>
          <Link href={p("/is-elanlari/baki/kuryer-catdirilma")}>{t.footer.couriers}</Link>
          <Link href={p("/vakansiyalar") + "?schedule=remote"}>{t.footer.remote}</Link>
          <Link href={p("/vakansiyalar") + "?schedule=part_time"}>{t.footer.partTime}</Link>
          <Link href={p("/elan-yerlesdir")}>{t.footer.post}</Link>
        </div>
        <p>© {new Date().getFullYear()} İşYeri.az. {t.footer.rights}</p>
      </div>
    </footer>
  );
}
