# Dəyişikliklər

## 0.3.0 — Görünüş rejimləri və animasiyalar
- Tema sistemi: Avto / Açıq / Qara / Göy. Seçim yadda qalır, açılışda yanıb-sönmə yoxdur, brauzer panelinin rəngi də dəyişir.
- Loqo temaya uyğunlaşır; yüklənəndə "pin düşür", üstünə gələndə portfel tərpənir. Favicon əlavə olundu (`app/icon.svg`).
- Ana səhifə: hərəkətli gradient fon, nöqtəli şəbəkə, başlıq animasiyası, 0-dan sayan statistika (vakansiya / şəhər / sahə).
- Sahə kartlarına ikonlar, hover effektləri.
- Vakansiya kartları: hover-da qalxma, ox işarəsi, "önə çıxan" kartlara xüsusi vurğu.
- Scroll ilə yumşaq görünmə (`Reveal`), səhifələr arası keçid animasiyası, yükləmə skeleti (`loading.tsx`).
- Yuxarıda oxuma zolağı, header kölgəsi, "yuxarı qayıt" düyməsi.
- Vakansiya səhifəsində "Paylaş" düyməsi.
- Elan göndəriləndə animasiyalı təsdiq işarəsi, xəta mətnləri yumşaq görünür.
- Mobil: header-də "Elan yerləşdir" kiçik "+" düyməsinə çevrilir.
- Əlçatanlıq: focus halqası, `prefers-reduced-motion` dəstəyi, rəng kontrastı yoxlanıb.

## 0.2.0 — Dillər
- Azərbaycan (əsas, prefikssiz), rus (`/ru`), ingilis (`/en`) dilləri; dil düyməsi.
- Hər səhifədə `hreflang`, canonical, 3 dilli sitemap.
- Şəhər, sahə, rayon və nümunə vakansiyaların tərcüməsi.
- Axtarış diakritiksiz işləyir (baki = Bakı); başlıqlarda "Gəncədə", "Şəkidə" şəkilçi xətası düzəldildi.

## 0.1.0 — İlk versiya
- Next.js 14 + Tailwind, nümunə data, elan yerləşdirmə forması, SEO.
